// const collection = require( '../utilities/connection' );
// const userData = [
  
// ];


let create = {}





// create.setupDB()

module.exports = create